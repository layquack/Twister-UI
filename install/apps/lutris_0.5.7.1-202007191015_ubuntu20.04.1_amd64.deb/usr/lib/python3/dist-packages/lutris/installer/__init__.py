"""Install script interpreter package."""
